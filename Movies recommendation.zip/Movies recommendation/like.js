fetch("https://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key=04c35731a5ee918f014970082a0088b1&page=1")
fetch("https://api.themoviedb.org/3/search/movie?&api_key=04c35731a5ee918f014970082a0088b1&query=")
fetch("https://image.tmdb.org/t/p/w1280")
  .then(response => response.json())
  .then(posts => {
    // Use the post data to create HTML elements for each post
  });
  const postContainer = document.getElementById('main');
posts.forEach(post => {
  const postElement = document.createElement('div');
  const titleElement = document.createElement('h2');
  const contentElement = document.createElement('p');
  const likeButton = document.createElement('button');
  const likeCountSpan = document.createElement('span');
  titleElement.textContent = post.title;
  contentElement.textContent = post.content;
  likeButton.textContent = 'Like';
  likeCountSpan.textContent = post.likes;
  likeButton.addEventListener('click', () => {
    // Update the like count for the post using the API
  });
  postElement.appendChild(titleElement);
  postElement.appendChild(contentElement);
  postElement.appendChild(likeButton);
  postElement.appendChild(likeCountSpan);
  postContainer.appendChild(postElement);
});

likeButton.addEventListener('click', () => {
    fetch(`"https://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key=04c35731a5ee918f014970082a0088b1&page=1"/${main.id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        likes: post.likes + 1
      })
    })
    .then(response => response.json())
    .then(updatedPost => {
      likeCountSpan.textContent = updatedPost.likes;
    });
  });