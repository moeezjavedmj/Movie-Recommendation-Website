const settings = {
	"async": true,
	"crossDomain": true,
	"url": "https://abir82-bollywood-recommendations.p.rapidapi.com/?year=2018&genre=Comedy",
	"method": "GET",
	"headers": {
		"X-RapidAPI-Key": "23f0bdb3e9mshb355040a8ca1928p16ac2bjsn730ae40eca64",
		"X-RapidAPI-Host": "abir82-bollywood-recommendations.p.rapidapi.com"
	}
};

$.ajax(settings).done(function (response) {
	console.log(response);
});
const apiEndpoint = 'https://api.themoviedb.org/3/movie/1234/recommendations';

// Set up the API key
const apiKey = '23f0bdb3e9mshb355040a8ca1928p16ac2bjsn730ae40eca64';

// Send a request to the API using AJAX
$.ajax({
  url: apiEndpoint,
  data: {
    api_key: apiKey,
  },
  success: function(response) {
    // Process the response from the API
    const recommendedMovies = response.results;
    // Display the recommended movies on your website
  },
  error: function(error) {
    console.log(error);
  },
});





